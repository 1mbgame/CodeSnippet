package com.mobile.app.database.entity;

import com.mobile.app.constant.UserRole;
import com.mobile.app.database.dto.UserDTO;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.Date;


@Entity
@DynamicUpdate
@Table(name = "user")
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    private String password;

    private String token;

    private String name;

    private String userRole;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    private boolean isDeleted;


    public UserDTO getUserDTO(){

        UserDTO userDTO = new UserDTO();

        userDTO.setEmail(getUsername());
        userDTO.setPassword(getPassword());
        userDTO.setName(getName());
        userDTO.setToken(getToken());
        userDTO.setDeleted(isDeleted());
        userDTO.setUserRole(getUserRole());
        userDTO.setUpdatedAt(getUpdatedAt());
        userDTO.setCreatedAt(getCreatedAt());

        return userDTO;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getName() {
        if(name == null){
            name = "";
        }
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserRole() {
        if(userRole == null){
            userRole = UserRole.USER;
        }
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}


