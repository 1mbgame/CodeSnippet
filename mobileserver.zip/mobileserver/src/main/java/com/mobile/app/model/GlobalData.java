package com.mobile.app.model;


import com.mobile.app.database.entity.UserEntity;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class GlobalData {
    private static GlobalData ourInstance = new GlobalData();

    public static GlobalData getInstance() {
        return ourInstance;
    }

    private GlobalData() {
    }

    // User mapping
    public Map<String, UserEntity> userTokenMap  = new ConcurrentHashMap<>();
    public Map<String, UserEntity> usernameMap = new ConcurrentHashMap<>();
    public Map<Long, UserEntity> userUserIdMap = new ConcurrentHashMap<>();


}
