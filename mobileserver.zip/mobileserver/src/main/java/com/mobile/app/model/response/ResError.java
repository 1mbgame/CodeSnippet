package com.mobile.app.model.response;

public class ResError {

    private int code;
    private String message = "";

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        if(message == null){
            message = "";
        }
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
