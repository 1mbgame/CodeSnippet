package com.mobile.app.controller;

import com.mobile.app.configSecurity.jwt.JwtTokenUtil;
import com.mobile.app.constant.UserRole;
import com.mobile.app.database.MyDb;
import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.service.UserService;
import com.mobile.app.model.request.LoginRequest;
import com.mobile.app.model.request.RegisterRequest;
import com.mobile.app.model.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Date;


@RestController
@RequestMapping(path = "/api/public/user")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService userService;

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


    @RequestMapping(method = RequestMethod.POST, path = "login")
    public ResponseEntity login(@RequestBody LoginRequest loginRequest){

        ResponseEntity responseEntity = getAuthenticatedResponseEntity(
                loginRequest.getUsername(),
                loginRequest.getPassword()
        );

        return responseEntity;
    }

    @PostMapping("register")
    public ResponseEntity getUserRegister(@RequestBody RegisterRequest registerRequest){



        if(userService.isUsernameFound(registerRequest.getUsername())){

            ApiResponse apiResponse = new ApiResponse();
            apiResponse.setSuccess(false);
            apiResponse.setErrorMessage("Username has been taken.");

            ResponseEntity responseEntity = ResponseEntity.ok(apiResponse);

            return responseEntity;
        }

        Date currentDate = new Date();
        UserEntity userEntity = new UserEntity();

        userEntity.setUsername(registerRequest.getUsername());
        userEntity.setPassword(passwordEncoder.encode(registerRequest.getPassword()));
        userEntity.setName("");
        userEntity.setToken(MyDb.getInstance().generateUniqueId());
        userEntity.setUserRole(UserRole.USER);
        userEntity.setUpdatedAt(currentDate);
        userEntity.setCreatedAt(currentDate);

        // Save the userEntity
        userService.save(userEntity);

        ResponseEntity responseEntity = getAuthenticatedResponseEntity(registerRequest.getUsername(),registerRequest.getPassword());


        return responseEntity;
    }

    private ResponseEntity getAuthenticatedResponseEntity(String username, String password){
        try {
            Authentication authenticate = authenticationManager
                    .authenticate(
                            new UsernamePasswordAuthenticationToken(
                                    username, password
                            )
                    );

            User user = (User) authenticate.getPrincipal();

            ResponseEntity responseEntity = ResponseEntity.ok()
                    .header(
                            HttpHeaders.AUTHORIZATION,
                            jwtTokenUtil.generateToken(user)
                    ).body("");


            return responseEntity;
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }


}
