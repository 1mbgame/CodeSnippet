package com.mobile.app.controller;


import com.mobile.app.configSecurity.CustomUserDetail;
import com.mobile.app.configSecurity.jwt.JwtTokenUtil;
import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.model.request.LoginRequest;
import com.mobile.app.model.request.RegisterRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("api")
public class UserController {

    @GetMapping("user")
    public String helloUser(@AuthenticationPrincipal CustomUserDetail customUserDetail) {

        UserEntity userEntity = customUserDetail.getUserEntity();

        return "Hello User, username: " + userEntity.getUsername();
    }

    @GetMapping("admin")
    public String helloAdmin() {
        return "Hello Admin";
    }


//    @GetMapping("/error")
//    public String getError(){
//
//        return "Error";
//    }

}
