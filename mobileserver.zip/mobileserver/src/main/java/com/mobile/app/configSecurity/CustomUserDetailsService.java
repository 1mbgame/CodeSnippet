package com.mobile.app.configSecurity;

import com.mobile.app.constant.UserRole;
import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserService userService;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        try {

            UserEntity userEntity = userService.getUserByUsername(username);
            List<SimpleGrantedAuthority> roles = Arrays.asList(new SimpleGrantedAuthority(userEntity.getUserRole()));

            CustomUserDetail userDetails = new CustomUserDetail(username, userEntity.getPassword(), roles);
            userDetails.setUserEntity(userEntity);

            return userDetails;

        } catch (Exception e) {
            e.printStackTrace();
        }


        return null;
    }
}
