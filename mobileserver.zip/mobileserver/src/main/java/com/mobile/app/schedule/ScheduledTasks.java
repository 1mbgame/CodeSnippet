package com.mobile.app.schedule;


import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTasks {


    // Run every 5 minutes
    @Scheduled(cron = "0 */5 * * * *")
    public void fiveMinuteTask() {

    }


    // Run at 1 AM Everyday
    @Scheduled(cron = "0 0 1 * * *")
    public void dailyTask() {

    }


    // Run every 3 hours
    @Scheduled(cron = "0 0 */3 * * *")
    public void runEvery6Hours() {

    }


}
