package com.mobile.app.controller;

import com.mobile.app.database.MyDb;
import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.service.UserService;
import com.mobile.app.library.MyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class ApiController {

    @Autowired
    UserService userService;

    @GetMapping("/create-user")
    public String createUser(){

        Date currentDate = new Date();

        UserEntity userEntity = new UserEntity();
        userEntity.setName("Andy-" + MyUtils.randomInteger(1,100));
        userEntity.setUsername(MyUtils.generateRandomString(5) + "@gmail.com");
        userEntity.setPassword("Abc123");
        userEntity.setToken(MyDb.getInstance().generateUniqueId());
        userEntity.setUpdatedAt(currentDate);
        userEntity.setCreatedAt(currentDate);

        userService.save(userEntity);

        return userEntity.getName();
    }

    @GetMapping("/get-name")
    public String getName(){
        return "Andy";
    }



    @RequestMapping(method = RequestMethod.GET, path = "/api-test")
    public String test(){
        return "Andy";
    }





}
