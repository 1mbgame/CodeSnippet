package com.mobile.app.database;

import com.mobile.app.library.MyUtils;

import java.util.Date;

public class MyDb {


    private static final MyDb ourInstance = new MyDb();

    public static MyDb getInstance() {
        return ourInstance;
    }


    StringBuffer stringBuffer = new StringBuffer();


    public synchronized String generateUniqueId(){
        stringBuffer.setLength(0);
        stringBuffer.append("D");
        stringBuffer.append(System.currentTimeMillis());
        stringBuffer.append("_");
        stringBuffer.append(MyUtils.generateRandomString(12));
        return stringBuffer.toString();
    }


}
