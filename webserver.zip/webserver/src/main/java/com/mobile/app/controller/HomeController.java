package com.mobile.app.controller;


import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.configSecurity.CustomUserDetail;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {





    @GetMapping("/")
    public String getCurrentUser(@AuthenticationPrincipal CustomUserDetail customUserDetail, Model model, HttpSession httpSession) {

        if(customUserDetail != null){
            try{
                UserEntity userEntity = customUserDetail.getUserEntity();
                System.out.println("Email =" + userEntity.getUsername());
            }catch (Exception e){
                e.printStackTrace();
            }
        }


        return "page/index";
    }




}
