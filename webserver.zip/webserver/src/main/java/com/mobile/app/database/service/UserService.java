package com.mobile.app.database.service;


import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.repository.UserRepository;
import com.mobile.app.model.GlobalData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;


@Service
public class UserService {

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    UserRepository userRepository;

    public void save(UserEntity userEntity){

        userRepository.save(userEntity);
        updateUserMapping(userEntity);
    }

    public void saveAll(List<UserEntity> userEntityList){
        for(UserEntity userEntity : userEntityList){
            updateUserMapping(userEntity);
        }
        userRepository.saveAll(userEntityList);
    }

    public int updateUserByUsername(String username){

        UserEntity userEntity = null;
        try{
            List<UserEntity> userEntityList = entityManager
                    .createQuery("select u from UserEntity u where u.username = :username", UserEntity.class)
                    .setParameter("username",username)
                    .setMaxResults(1)
                    .getResultList();

            if(userEntityList.size() > 0){
                userEntity = userEntityList.get(0);
                updateUserMapping(userEntity);

                return 1;
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return 0;
    }

    public UserEntity getUserByUsername(String username){

        UserEntity userEntity = GlobalData.getInstance().usernameMap.get(username);
        if(userEntity != null){
            return userEntity;
        }

        try{
            List<UserEntity> userEntityList = entityManager
                    .createQuery("select u from UserEntity u where u.username = :username", UserEntity.class)
                    .setParameter("username",username)
                    .setMaxResults(1)
                    .getResultList();

            if(userEntityList.size() > 0){
                userEntity = userEntityList.get(0);
                updateUserMapping(userEntity);
                return userEntity;
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    public UserEntity getUserById(Long id){

        UserEntity userEntity = GlobalData.getInstance().userUserIdMap.get(id);
        if(userEntity != null){
            return userEntity;
        }

        try{

            userEntity = userRepository.findById(id).get();

            return userEntity;

        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    public UserEntity getUserByToken(String token){

        UserEntity userEntity = GlobalData.getInstance().userTokenMap.get(token);
        if(userEntity != null){
            return userEntity;
        }

        try{
            List<UserEntity> userEntityList = entityManager
                    .createQuery("select u from UserEntity u where u.token = :token", UserEntity.class)
                    .setParameter("token",token)
                    .setMaxResults(1)
                    .getResultList();

            if(userEntityList.size() > 0){
                userEntity = userEntityList.get(0);
                updateUserMapping(userEntity);
                return userEntity;
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    public boolean isUserIdFound(long id){

        UserEntity userEntity = GlobalData.getInstance().userUserIdMap.get(id);
        if(userEntity != null){
            return true;
        }



        try{

            boolean isFound = userRepository.existsById(id);

            return isFound;

        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean isUsernameFound(String username){

        UserEntity userEntity = GlobalData.getInstance().usernameMap.get(username);
        if(userEntity != null){
            return true;
        }

        try{
            Long count = (Long) entityManager
                    .createQuery("select Count(u) from UserEntity u where u.username = :username")
                    .setParameter("username", username)
                    .getSingleResult();
            if(count > 0){

                userEntity = getUserByUsername(username);
                updateUserMapping(userEntity);

                return true;
            }else{
                return false;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return false;

    }

    private void updateUserMapping(UserEntity userEntity){
        GlobalData.getInstance().userTokenMap.put(userEntity.getToken(), userEntity);
        GlobalData.getInstance().userUserIdMap.put(userEntity.getId(), userEntity);
        GlobalData.getInstance().usernameMap.put(userEntity.getUsername(), userEntity);
    }



    public List<UserEntity> getVipUserId() {

        try{
            List<UserEntity> userEntityList = entityManager
                    .createQuery("select u from UserEntity u where u.vipCode > :vipCode ", UserEntity.class)
                    .setParameter("vipCode",0)
                    .getResultList();
            return userEntityList;
        }catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

}
