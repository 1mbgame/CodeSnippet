package com.mobile.app.model.request;

public class FormRegister {

    private String name;
    private String username;
    private String password;
    private String confirmPassword;
    private String error;


    public String getName() {
        if(name == null){
            name = "";
        }
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        if(username == null){
            username = "";
        }else{
            username = username.trim();
        }
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getError() {
        if(error == null){
            error = "";
        }
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
