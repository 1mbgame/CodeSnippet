package com.mobile.app.constant;

public class UserRole {

    public static final String ADMIN = "ADMIN";
    public static final String USER = "USER";

}
