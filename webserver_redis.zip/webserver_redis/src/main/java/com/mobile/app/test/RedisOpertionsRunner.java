package com.mobile.app.test;


import java.util.Map;

import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.service.UserService;
import com.mobile.app.model.redis.dao.IEmployeeDao;
import com.mobile.app.model.redis.entity.Employee;
import net.sf.ehcache.CacheManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


@Component
public class RedisOpertionsRunner implements CommandLineRunner {

    @Autowired
    private IEmployeeDao empDao;

    @Autowired
    private UserService userService;

    @Override
    public void run(String... args) throws Exception {

        //testRedisServer();


    }

    private void testRedisServer(){
        //saving one employee
        empDao.saveEmployee(new Employee(500, "Emp0", 2150.0));

        //saving multiple employees
        Map<Integer, Employee> map = new java.util.HashMap<>();
        map.put(501, new Employee(501, "Emp1", 2396.0));
        map.put(502, new Employee(502, "Emp2", 2499.5));
        map.put(503, new Employee(503, "Emp4", 2324.75));
        empDao.saveAllEmployees(map);

        //modifying employee with empId 503
        empDao.updateEmployee(new Employee(503, "Emp3", 2325.25));

        //deleting employee with empID 500
        empDao.deleteEmployee(500);

        //retrieving all employees
        empDao.getAllEmployees().forEach((k,v)-> System.out.println(k +" : "+v));

        //retrieving employee with empID 501
        System.out.println("Emp details for 501 : "+empDao.getOneEmployee(501));

    }


}
