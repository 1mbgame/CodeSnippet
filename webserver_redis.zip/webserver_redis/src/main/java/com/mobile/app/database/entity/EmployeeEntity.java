package com.mobile.app.database.entity;


public class EmployeeEntity {
}
