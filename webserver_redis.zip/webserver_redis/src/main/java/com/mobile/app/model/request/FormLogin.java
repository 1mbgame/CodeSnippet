package com.mobile.app.model.request;





public class FormLogin {

    public FormLogin(){
        this.username = "";
        this.password = "";
        this.error = "";
    }

    private String username;

    private String password;

    private String error;

    private String googleRecaptcha;

    public String getUsername() {
        if(username == null) {
            username = "";
        }
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        if(password == null){
            password = "";
        }
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getError() {
        if(error == null){
            error = "";
        }
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getGoogleRecaptcha() {
        return googleRecaptcha;
    }

    public void setGoogleRecaptcha(String googleRecaptcha) {
        this.googleRecaptcha = googleRecaptcha;
    }

    @Override
    public String toString() {
        return "LoginForm{" +
               "username='" + username + '\'' +
               ", password='" + password + '\'' +
               ", error='" + error + '\'' +
               '}';
    }
}
