package com.mobile.app.controller;


import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.configSecurity.CustomUserDetail;
import com.mobile.app.database.service.UserService;
import net.sf.ehcache.CacheManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {


    @Autowired
    UserService userService;



    @GetMapping("/")
    public String getCurrentUser(@AuthenticationPrincipal CustomUserDetail customUserDetail, Model model, HttpSession httpSession) {

        if(customUserDetail != null){
            try{
                UserEntity userEntity = customUserDetail.getUserEntity();
                System.out.println("Email =" + userEntity.getUsername());
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        testHibernateCache();

        return "page/index";
    }


    private void testHibernateCache(){
//        UserEntity userEntity = userService.getUserById(1L);
        UserEntity userEntity = userService.getUserByUsername("andy1@gmail.com");

        System.out.println("Username: " + userEntity.getToken());

    }


}
