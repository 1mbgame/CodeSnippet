package com.mobile.app.config;



public class AppConfig {

    public static final boolean isDebug = true;

    // Debug
    public static final String debugRootFolder = "D:/project_andy/my_project_2020/lantian/cloud_deploy/";
    //public static final String debugRootFolder = "/Volumes/MYDATA/project_andy/my_project_2020/lantian/cloud_deploy/";
    public static final String debugUrl = "http://127.0.0.1";

    // Production
    public static final String prodRootFolder = "/home/ubuntu/viewcoco/";
    public static final String productionUrl = "http://viewcoco.com";



    // Root Folder
    public static String rootFolder = prodRootFolder;
    public static String url = productionUrl;

    public static void init() {
        if (isDebug == true) {
            rootFolder = debugRootFolder;
            url = debugUrl;
        } else {
            rootFolder = prodRootFolder;
            url = productionUrl;
        }
    }


}
