package com.mobile.app.controller;


import com.mobile.app.configSecurity.CustomUserDetail;
import com.mobile.app.constant.SessionName;
import com.mobile.app.constant.UserRole;
import com.mobile.app.database.MyDb;
import com.mobile.app.database.entity.UserEntity;
import com.mobile.app.database.service.UserService;
import com.mobile.app.model.request.FormLogin;
import com.mobile.app.model.request.FormRegister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;

@Controller
public class UserController {

    @Autowired
    UserService userService;


    PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(
            @AuthenticationPrincipal CustomUserDetail customUserDetail,
            Model model,
            HttpSession httpSession
    ) {

        if (customUserDetail != null) {
            return "redirect:/";
        }



        FormLogin formLogin = (FormLogin) httpSession.getAttribute(SessionName.LOGIN_FORM);
        if (formLogin == null) {
            formLogin = new FormLogin();
            httpSession.setAttribute(SessionName.LOGIN_FORM, formLogin);
        }

        formLogin.setPassword("");
        formLogin.setError("");


        model.addAttribute("formLogin", formLogin);
        model.addAttribute("content", "page/auth/login");

        return "fragment/template_auth";
    }

    @RequestMapping(value = "/user/register", method = RequestMethod.GET)
    public String register(Model model, HttpSession httpSession) {

        FormRegister formRegister = (FormRegister) httpSession.getAttribute(SessionName.REGISTRATION_FORM);
        if (formRegister == null) {
            formRegister = new FormRegister();
        }


        model.addAttribute("formRegister", formRegister);
        model.addAttribute("content", "page/auth/register");


        return "fragment/template_auth";
    }

    @RequestMapping(value = "/user/register", method = RequestMethod.POST)
    public String login(FormRegister formRegister, Model model, HttpSession httpSession) {

        httpSession.setAttribute(SessionName.LAST_PAGE, "/user/register");
        httpSession.setAttribute(SessionName.REGISTRATION_FORM, formRegister);


        if (formRegister.getPassword().isEmpty() || formRegister.getUsername().isEmpty()) {
            formRegister.setError("The email or password can not be empty!");
            model.addAttribute("formRegister", formRegister);
            model.addAttribute("content", "page/auth/register");
            return "fragment/template_auth";
        }

        if (!formRegister.getPassword().equals(formRegister.getConfirmPassword())) {
            formRegister.setError("Password not match!");
            model.addAttribute("formRegister", formRegister);
            model.addAttribute("content", "page/auth/register");
            return "fragment/template_auth";
        }

        if(userService.isUsernameFound(formRegister.getUsername())){
            formRegister.setError("Email has been taken!");
            model.addAttribute("formRegister", formRegister);
            model.addAttribute("content", "page/auth/register");
            return "fragment/template_auth";
        }

        // Create currentDate instance
        Date currentDate = new Date();

        // Create a new User instance
        UserEntity userEntity = new UserEntity();
        userEntity.setName(formRegister.getName());
        userEntity.setUsername(formRegister.getUsername());
        userEntity.setPassword(passwordEncoder.encode(formRegister.getPassword()));
        userEntity.setToken(MyDb.getInstance().generateUniqueId());
        userEntity.setUserRole(UserRole.USER);
        userEntity.setCreatedAt(currentDate);
        userEntity.setUpdatedAt(currentDate);

        // Save the user into database
        userService.save(userEntity);


        return "redirect:/";

    }

    @RequestMapping(value="/logout", method=RequestMethod.GET)
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/";
    }
}
