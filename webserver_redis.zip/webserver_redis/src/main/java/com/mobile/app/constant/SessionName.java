package com.mobile.app.constant;

public class SessionName {

    public static final String LAST_PAGE = "LAST_PAGE";
    public static final String USER = "USER";
    public static final String LOGIN_FORM = "LOGIN_FORM";
    public static final String REGISTRATION_FORM = "REGISTRATION_FORM";



}
